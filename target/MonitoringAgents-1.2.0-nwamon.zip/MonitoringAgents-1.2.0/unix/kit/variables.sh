#!/bin/sh
JAVA=/usr/bin/java